# Calmornia Proximity Chat — Full Starter

## What this version does

- Node.js backend
- WebSocket signaling
- WebRTC peer-to-peer voice
- Room system
- Player names
- Live player coordinates
- Distance-based remote audio volume
- Adjustable hearing range
- Bedrock bridge API
- Mobile-friendly website

## 1. Install

Install Node.js 20+.

Then:

```bash
npm install
```

## 2. Configure

Copy `.env.example` to `.env` and set a strong `BRIDGE_TOKEN`.

For a quick local test:

```bash
npm start
```

Open:

http://localhost:3000

Microphone access works on localhost. For public hosting, use HTTPS.

## 3. How proximity works

Each browser connects to the Node.js WebSocket server.

The server keeps each player's:
- Minecraft name
- X/Y/Z
- voice range

The browsers establish WebRTC connections between players.

Every 500 ms the client calculates 3D distance:

distance = sqrt((x1-x2)^2 + (y1-y2)^2 + (z1-z2)^2)

If the player is outside the configured range, their audio is muted.
Inside the range, volume falls off as distance increases.

## 4. Bedrock integration

The backend exposes:

POST /api/bedrock/position

with:

Authorization: Bearer BRIDGE_TOKEN

JSON:

{
  "room": "calmornia",
  "name": "PlayerName",
  "x": 123,
  "y": 64,
  "z": -42
}

See `bedrock-bridge-example.js`.

### Important Bedrock note

The website/backend cannot magically read a Bedrock server's coordinates.
You need a server-side bridge that can send player coordinates to the API.

The exact bridge depends on your Bedrock hosting/server software and what scripting/network APIs it supports.

## 5. Production considerations

For a public server, add:
- HTTPS
- WSS
- authentication/player verification
- rate limiting
- room access control
- TURN server for players behind restrictive NATs
- moderation/mute/report controls
- server-side validation of coordinates
- maximum room size

For larger rooms, use a WebRTC SFU instead of a full peer-to-peer mesh.

## Architecture

Minecraft Bedrock
       |
       | player position
       v
Bedrock bridge
       |
       | HTTPS
       v
Node.js backend
       |
       | WebSocket signaling
       v
Web browsers
       |
       | WebRTC audio
       v
Nearby players
