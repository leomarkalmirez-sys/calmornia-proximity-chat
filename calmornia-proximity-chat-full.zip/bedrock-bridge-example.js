/*
 CALMORNIA BEDROCK BRIDGE EXAMPLE

 This file shows the data that your Bedrock-side integration needs to send
 to the Node.js backend. The exact HTTP API available to your Bedrock server
 depends on the server software/addons you use.

 Endpoint:
 POST https://YOUR-DOMAIN/api/bedrock/position

 Headers:
 Authorization: Bearer YOUR_BRIDGE_TOKEN
 Content-Type: application/json

 JSON:
 {
   "room": "calmornia",
   "name": "PlayerName",
   "x": 123,
   "y": 64,
   "z": -42
 }

 IMPORTANT:
 This example is intentionally separated from the web backend because
 ordinary Bedrock behavior packs do not universally provide unrestricted
 outbound HTTP networking. If your server supports an HTTP-capable bridge,
 adapt this payload to that bridge/plugin.

 Send position updates every ~500-1000 ms, or only when a player moves.
 Do not expose BRIDGE_TOKEN inside the public website.
*/