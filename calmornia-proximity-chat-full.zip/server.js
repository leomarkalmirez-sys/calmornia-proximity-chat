import express from "express";
import http from "http";
import crypto from "crypto";
import { WebSocketServer } from "ws";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const BRIDGE_TOKEN = process.env.BRIDGE_TOKEN || "change-this-token";

const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

/*
  rooms:
    roomId -> Map(clientId, {
      ws, name, x, y, z, range, joinedAt
    })

  The server only handles signaling and player position metadata.
  Audio is peer-to-peer through WebRTC.
*/
const rooms = new Map();

function cleanName(v) {
  return String(v ?? "").trim().slice(0, 24).replace(/[^\w .-]/g, "");
}
function cleanRoom(v) {
  return String(v ?? "calmornia").trim().slice(0, 32).replace(/[^\w-]/g, "").toLowerCase() || "calmornia";
}
function broadcast(roomId, message, exceptId = null) {
  const room = rooms.get(roomId);
  if (!room) return;
  const payload = JSON.stringify(message);
  for (const [id, p] of room) {
    if (id !== exceptId && p.ws.readyState === 1) p.ws.send(payload);
  }
}
function snapshot(roomId) {
  const room = rooms.get(roomId);
  if (!room) return [];
  return [...room].map(([id, p]) => ({
    id, name: p.name, x: p.x, y: p.y, z: p.z, range: p.range
  }));
}
function removeClient(id, roomId) {
  const room = rooms.get(roomId);
  if (!room) return;
  room.delete(id);
  broadcast(roomId, { type: "player-left", id });
  if (!room.size) rooms.delete(roomId);
}

wss.on("connection", ws => {
  const id = crypto.randomUUID();
  let roomId = null;

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "join") {
      roomId = cleanRoom(msg.room);
      const name = cleanName(msg.name) || "Player";
      if (!rooms.has(roomId)) rooms.set(roomId, new Map());

      const room = rooms.get(roomId);
      room.set(id, {
        ws, name,
        x: Number(msg.x) || 0,
        y: Number(msg.y) || 64,
        z: Number(msg.z) || 0,
        range: Math.max(4, Math.min(128, Number(msg.range) || 32)),
        joinedAt: Date.now()
      });

      ws.send(JSON.stringify({
        type: "joined",
        id,
        room: roomId,
        players: snapshot(roomId)
      }));
      broadcast(roomId, {
        type: "player-joined",
        player: { id, name, x: 0, y: 64, z: 0, range: 32 }
      }, id);
      return;
    }

    if (!roomId || !rooms.has(roomId)) return;
    const room = rooms.get(roomId);
    const me = room.get(id);
    if (!me) return;

    if (msg.type === "position") {
      me.x = Number(msg.x) || 0;
      me.y = Number(msg.y) || 64;
      me.z = Number(msg.z) || 0;
      broadcast(roomId, {
        type: "player-position",
        id, x: me.x, y: me.y, z: me.z
      }, id);
    }

    if (msg.type === "range") {
      me.range = Math.max(4, Math.min(128, Number(msg.range) || 32));
      broadcast(roomId, { type: "player-range", id, range: me.range }, id);
    }

    // WebRTC signaling: offer/answer/ICE stays inside the room.
    if (["offer", "answer", "ice"].includes(msg.type)) {
      const target = room.get(msg.to);
      if (target?.ws.readyState === 1) {
        target.ws.send(JSON.stringify({ ...msg, from: id }));
      }
    }
  });

  ws.on("close", () => removeClient(id, roomId));
  ws.on("error", () => removeClient(id, roomId));
});

/*
  Bedrock bridge endpoint.
  Your server-side bridge can POST:
  {
    "token":"...",
    "room":"calmornia",
    "name":"PlayerName",
    "x":123,
    "y":64,
    "z":-42
  }

  This updates the matching web client by Minecraft name.
*/
app.post("/api/bedrock/position", (req, res) => {
  if (req.headers.authorization !== `Bearer ${BRIDGE_TOKEN}`) {
    return res.status(401).json({ error: "unauthorized" });
  }

  const { room: rawRoom, name: rawName, x, y, z } = req.body || {};
  const roomId = cleanRoom(rawRoom);
  const name = cleanName(rawName);
  const room = rooms.get(roomId);

  if (!room) return res.json({ updated: false, reason: "room-empty" });

  let updated = 0;
  for (const [, p] of room) {
    if (p.name.toLowerCase() === name.toLowerCase()) {
      p.x = Number(x) || 0;
      p.y = Number(y) || 64;
      p.z = Number(z) || 0;
      p.ws.send(JSON.stringify({
        type: "server-position",
        x: p.x, y: p.y, z: p.z
      }));
      broadcast(roomId, {
        type: "player-position",
        id: [...room].find(([, q]) => q === p)?.[0],
        x: p.x, y: p.y, z: p.z
      });
      updated++;
    }
  }
  res.json({ updated });
});

app.get("/api/health", (_, res) => res.json({
  ok: true,
  rooms: rooms.size,
  time: new Date().toISOString()
}));

app.get("*", (_, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

server.listen(PORT, () => {
  console.log(`Calmornia Proximity Chat running on port ${PORT}`);
});