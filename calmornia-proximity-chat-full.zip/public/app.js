let ws=null, localId=null, stream=null, muted=false;
const peers=new Map(), players=new Map();
const $=id=>document.getElementById(id);
const me=()=>({x:+$("x").value||0,y:+$("y").value||64,z:+$("z").value||0});
const distance=(a,b)=>Math.sqrt((a.x-b.x)**2+(a.y-b.y)**2+(a.z-b.z)**2);

function send(m){if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(m))}
function render(){
  const p=me(), range=+$("range").value;
  $("rangeLabel").textContent=range;
  $("players").innerHTML=[...players.values()].map(q=>{
    const d=Math.round(distance(p,q)), heard=d<=range;
    return `<div class="player">
      <span class="dot" style="opacity:${heard?1:.2}"></span>
      <span class="avatar">${(q.name||"?")[0]}</span>
      <span class="meta"><b>${q.name}</b><small>${heard?"Within range":"Out of range"}</small></span>
      <span class="distance">${d} blocks</span>
    </div>`;
  }).join("") || `<p class="hint">No other players in this room.</p>`;
}
function setRemoteVolume(id){
  const peer=peers.get(id); const q=players.get(id); if(!peer||!q)return;
  const d=distance(me(),q), range=+$("range").value;
  // Browser audio output is controlled by the remote <audio> element.
  const audio=peer.audio;
  if(audio){
    const t=Math.max(0,Math.min(1,1-(d/range)));
    audio.volume=t*t;
    audio.muted=d>range;
  }
}
async function makePeer(id,initiator){
  const pc=new RTCPeerConnection({iceServers:[
    {urls:"stun:stun.l.google.com:19302"}
  ]});
  const obj={pc,audio:null}; peers.set(id,obj);
  if(stream)stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  pc.onicecandidate=e=>{if(e.candidate)send({type:"ice",to:id,candidate:e.candidate})};
  pc.ontrack=e=>{
    let a=obj.audio;
    if(!a){a=document.createElement("audio");a.autoplay=true;a.playsInline=true;document.body.appendChild(a);obj.audio=a}
    a.srcObject=e.streams[0]; obj.audio=a; setRemoteVolume(id);
  };
  pc.onconnectionstatechange=()=>{
    if(["failed","closed","disconnected"].includes(pc.connectionState)){pc.close();peers.delete(id)}
  };
  if(initiator){
    const offer=await pc.createOffer(); await pc.setLocalDescription(offer);
    send({type:"offer",to:id,sdp:pc.localDescription});
  }
  return pc;
}
async function join(){
  const name=$("name").value.trim();
  if(!name)return alert("Enter your Minecraft name.");
  try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}})}
  catch(e){return alert("Microphone permission is required.")}
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}/ws`);
  ws.onopen=()=>send({type:"join",name,room:$("room").value.trim()||"calmornia",...me(),range:+$("range").value});
  ws.onmessage=async ev=>{
    const m=JSON.parse(ev.data);
    if(m.type==="joined"){
      localId=m.id; $("roomName").textContent=m.room.toUpperCase();
      for(const q of m.players){players.set(q.id,q)}
      $("join").classList.add("hidden");$("app").classList.remove("hidden");
      $("status").textContent="ONLINE";$("status").className="pill on";render();
      for(const q of m.players){if(q.id!==localId && q.id>localId)await makePeer(q.id,true)}
    }
    if(m.type==="player-joined"){players.set(m.player.id,m.player);render();if(m.player.id>localId)await makePeer(m.player.id,true)}
    if(m.type==="player-left"){players.delete(m.id);peers.get(m.id)?.pc.close();peers.delete(m.id);render()}
    if(m.type==="player-position"){let q=players.get(m.id);if(q)Object.assign(q,{x:m.x,y:m.y,z:m.z});render();setRemoteVolume(m.id)}
    if(m.type==="server-position"){$("x").value=m.x;$("y").value=m.y;$("z").value=m.z;render()}
    if(m.type==="player-range"){let q=players.get(m.id);if(q)q.range=m.range}
    if(m.type==="offer"){
      const pc=peers.get(m.from)?.pc || (await makePeer(m.from,false)).pc;
      await pc.setRemoteDescription(m.sdp);const a=await pc.createAnswer();await pc.setLocalDescription(a);
      send({type:"answer",to:m.from,sdp:pc.localDescription});
    }
    if(m.type==="answer"){const pc=peers.get(m.from)?.pc;if(pc)await pc.setRemoteDescription(m.sdp)}
    if(m.type==="ice"){const pc=peers.get(m.from)?.pc;if(pc)try{await pc.addIceCandidate(m.candidate)}catch{}}
  };
  ws.onclose=()=>{ $("status").textContent="OFFLINE";$("status").className="pill off" };
}
$("joinBtn").onclick=join;
$("mic").onclick=()=>{muted=!muted;if(stream)stream.getAudioTracks().forEach(t=>t.enabled=!muted);$("micState").textContent=muted?"Microphone muted":"Microphone on";$("mic").classList.toggle("muted",muted)};
$("range").oninput=()=>{send({type:"range",range:+$("range").value});render();for(const id of peers.keys())setRemoteVolume(id)};
["x","y","z"].forEach(id=>$(id).oninput=()=>{send({type:"position",...me()});render();for(const q of peers.keys())setRemoteVolume(q)});
$("leave").onclick=()=>location.reload();
setInterval(()=>{for(const id of peers.keys())setRemoteVolume(id)},500);